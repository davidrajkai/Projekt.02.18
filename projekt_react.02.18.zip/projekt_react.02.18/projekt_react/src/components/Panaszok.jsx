const Panaszok = (props) => {
    <article id="panasz-1" class="panasz-container" className="panasz">

        <h4>Panasz adatok:</h4>

        <p><strong>Név:</strong> {props.neve}</p>
        <p><strong>Dátum:</strong> {props.datum}</p>
        <p><strong>Kinek:</strong> {props.kinek}</p>
        <p><strong>Panasz:</strong> {props.panasz}</p>

        <button className="icon-button" onClick={props.torles}>
            🗑
        </button>
    </article>;
};