import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  function Complaint() {
    const myHeaders = new Headers();
    myHeaders.set("Content-Type", "text/html");
    myHeaders.set("Access-Control-Allow-Origin", "http://localhost:5173/");
    myHeaders.set("Access-Control-Allow-Headers", "Origin");

    const xhr = new XMLHttpRequest();
    xhr.open("GET", "http://127.0.0.1:8000/api/");

    xhr.onload = function () {
      if (xhr.status === 200) {
        setData(JSON.parse(xhr.responseText));
      } else {
        console.log("Hiba");
      }
    };
    xhr.send();
  }

  const [data, setData] = useState(null);

  return (
    <>
      {Complaint()}
      {data ? <div>{WriteJson(data)}</div> : <div></div>}
    </>
  );
}


export default App
