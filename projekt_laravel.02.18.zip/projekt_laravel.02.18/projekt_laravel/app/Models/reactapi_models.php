<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class reactapi_models extends Model
{
    //
}
