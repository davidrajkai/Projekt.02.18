<?php

namespace App\Http\Controllers;

use App\Models\reactapi_models;
use Illuminate\Http\Request;

class reactapi_controller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $rev = reactapi_models::all();
        return response()->json($rev);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $rev = reactapi_models::all();
        return view('panasz.create', compact('rev'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request -> validate([
            'neve' => 'required',
            'datum' => 'required',
            'panasz' => 'required',
            'kinek' => 'required',
            
        ],
        [
            'neve.required' => 'A nev mezo nem lehet ures',
            'panasz.required' => 'A nem mezo nem lehet ures',
            'kinek.required' => 'A nem mezo nem lehet ures',
            
        ]
    );

    $con = new reactapi_models();
    $con -> neve = $request -> neve;
    $con -> datum = $request -> datum;
    $con -> panasz = $request -> panasz;
    $con -> kinek = $request -> kinek;

    $con-> save();

    return redirect()->route('panasz.create')->with('success', 'szep munka');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $rev = reactapi_models::all();
        if(empty($rev)){
            return response()->json(['masseg' => 'panasz nincs meg'], 404);
        }
        else{
            return response()->json($rev);
        };
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $rev = reactapi_models::find($id);
        if(empty($rev))
        {
            $rev -> delete();
            return response()->json(["masseg" => "panasz torolve"], 202);
        }
        else{
            return response()-> json(["masseg" => "panasz nincs meg"], 404);
        }
    }
}
