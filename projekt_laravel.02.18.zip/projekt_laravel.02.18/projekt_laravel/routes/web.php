<?php

use App\Http\Controllers\reactapi_controller;
use Illuminate\Support\Facades\Route;
/*
Route::get('/', function () {
    return view('welcome');
});
*/


Route::middleware('react_api');

Route::get('/rev/{id}' ,[reactapi_controller::class, 'index']);

Route::delete('/rev/{id},' ,[reactapi_controller::class , 'destroy']);
